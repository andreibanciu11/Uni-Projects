public class Main {
    public static void main(String[] args) {
        Bank bank = new Bank(10, 100, 100);
        bank.run();
    }
}