package Model;

public enum Approach {
    CLASSIC,
    THREAD_POOL
}
