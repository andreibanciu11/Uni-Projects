package Model;

public enum Strategy {
    ROWS,
    COLUMNS,
    KTH
}
